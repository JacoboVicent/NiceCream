
package nicecream;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import nicecream.Cola.NodoCola;

/**
 *
 * @author USUARIO
 */
public class NiceCream {

    public static void main(String[] args) {
int opcion = 0;
        System.out.println("Los clientes seran cargados ");
        
        Clientes Cola = new Clientes();
        

        String rutaProyecto = (new File(".")).getAbsolutePath();
        String[] arregloTemporal = leerArchivo(rutaProyecto + "/src/nicecream/Clientes.in").split("@");
        for (String string : arregloTemporal) {
            String[] datosClientes = string.split(",");
            Cola.Cliente(
                datosClientes[0],
                datosClientes[1], 
                datosClientes[2], 
                datosClientes[3],
                datosClientes[4], 
                Integer.valueOf(datosClientes[5])
            );
            Cola.total++;
        }
        
        for (int i = 0; i < Cola.Clientes.getTotalCola(); i++) {
            NodoCola ClienteAux = Cola.Clientes.getNodeColaAt(i);
            ClienteAux.dato.imprimirDatos();
        }
        
        do{
            menu();
            Scanner data = new Scanner(System.in);
            opcion = Integer.valueOf(data.nextLine());
            try {
                
                if(opcion == 4){
                    System.out.println("Saliendo del sistema");
                    break;
                }
                
                switch (opcion) {
                    case 1:
                        Cola.atenderCliente();
                    break;
                    case 2:
                        
                    break;
                    case 3:
                        
                    break;
                    default:
                            System.out.println("Opcion ingresada es invalida");;
                    break;
                }
                
            } catch (Exception e){
                System.out.println("Ingreso un dato invalido");
                e.printStackTrace();
            }
            
        } while (opcion != 4);
        

        
        
    }
    
    public static void escribirArchivo(String[] lineas, String ruta) {
        FileWriter fichero = null;
        PrintWriter pw = null;
        try {
            fichero = new FileWriter(ruta);
            pw = new PrintWriter(fichero);

            for (String string : lineas) {
                pw.println(string);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (null != fichero)
                    fichero.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }
        
    public static String leerArchivo(String ruta) {
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;

        String data = "@";

        try {
            archivo = new File(ruta);
            fr = new FileReader(archivo);
            br = new BufferedReader(fr);
            String linea;
            while ((linea = br.readLine()) != null)
                data = data + linea + "@";
        } catch (IOException e) {
        } finally {
            try {
                if (null != fr) {
                    fr.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }

        return data;
    }
    
    public static void menu(){
        System.out.println(
                "1.- Atender Clientes");
        System.out.println(
                "2.- Reporte de ventas");
        System.out.println(
                "3.- Ranking de ventas");
        System.out.println(
                "4.- Salir");
    }
}
    



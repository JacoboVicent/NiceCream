//El nodo para determinar el sabor de helado
package nicecream;

/**
 *
 * @author USUARIO
 */
public class Nodo {
    String SabordeHelado;
    Nodo sig;
    
    public Nodo (String SabordeHelado, Nodo sig){
        this.SabordeHelado = SabordeHelado;
        this.sig = sig;
    }
    
    public Nodo (String SabordeHelado) {
        this.SabordeHelado = SabordeHelado;
    }
}

//Los datos de la venta del helado (incompleto)
package nicecream;

/**
 *
 * @author USUARIO
 */
public class Helado {
    String dato;
    String cliente;
    int montoVenta;
    
    public Helado(String dato, String cliente, int montoVenta){
        this.dato=dato;
        this.cliente=cliente;
        this.montoVenta=montoVenta;   
    }
}

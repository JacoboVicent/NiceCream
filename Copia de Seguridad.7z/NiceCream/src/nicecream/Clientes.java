
package nicecream;

import java.util.Scanner;

/**
 *
 * @author USUARIO
 */

    public class Clientes {
    Cola Clientes = new Cola();
    Scanner data = new Scanner(System.in);
    int total = 0;
    
    public void aggCliente(String Nombre, String Apellido, String Cedula,double Saldo){
        Cliente NuevoCliente = new Cliente(Nombre, Apellido, Cedula, Saldo);
        Clientes.agregar(NuevoCliente);
    }
    
    public void atenderCliente(){
        System.out.println("Los clientes seran atendidos \n");
        Pila infoHelados = new Pila();
        for (int i = 0; i < this.Clientes.getTotalCola(); i++) {
            Cola.NodoCola ClienteAux = this.Clientes.getNodeColaAt(i);
            System.out.println("Buenos dias "+ClienteAux.dato.nombre+" "+ClienteAux.dato.apellido+" ");
            System.out.println("Su saldo es de: $"+ClienteAux.dato.saldo+" ");
            System.out.println("Por favor chequee nuestros precios:");
            
            System.out.println("Barquilla de 1 porcion de helado y 1 topping = 2$");
            System.out.println("Helado adicional (Maximo 2 sabores adicionales ) = 2$ ");
            System.out.println("Topping adicional (Maximo 2 topping adicionales) = 2$ ");
            
            Tipos Heladeria = new Tipos();
           
            String opcion = "h";
            do {
                int n = 0;
                boolean validaTopping = false;
                for (int j = 0; j < 3; j++) {
                    System.out.println("Desea pedir un helado ? (s/n):");
                
                    opcion = this.data.nextLine();
                    if("s".equals(opcion)){
                        if(ClienteAux.dato.saldo < 1){
                            System.out.println("Su saldo es insuficiente para realizar una Compra");
                            break;
                        }
                        
                        int opcion2=Heladeria.Sabores.length+2;
                        do {
                            System.out.println("Estas son nuestras opciones de sabores:");

                            for (int k = 0; k < Heladeria.Sabores.length; k++) {
                                System.out.println("(" + (k+1) + ") " + Heladeria.Sabores[k]);
                            }

                            opcion2 = Integer.valueOf(this.data.nextLine());
                            if (n==0) {
                                Helado infoHeladoTemp = new Helado(Heladeria.Sabores[(opcion2-1)],ClienteAux.dato.cedula,2);
                                infoHelados.agregar(infoHeladoTemp);
                                ClienteAux.dato.saldo-=2;
                            }else{
                                Helado infoHeladoTemp = new Helado(Heladeria.Sabores[(opcion2-1)],ClienteAux.dato.cedula,1);
                                infoHelados.agregar(infoHeladoTemp);
                                ClienteAux.dato.saldo-=1;
                            }
                            
                        } while (opcion2>(Heladeria.Sabores.length+2));
                        
                        
                        String opcion3 = "s";
                        if(j > 0){
                            System.out.println("Desea añadirle algun topping adicional? (s/n):");
                            opcion3 = this.data.nextLine();
                        }
                        
                        if("s".equals(opcion3)){
                            if(ClienteAux.dato.saldo < 1 && n == 0){
                                System.out.println("Saldo insuficiente");
                                break;
                            }
                            int opcion4=Heladeria.Toppings.length+2;
                            
                            do {
                                for (int l = 0; l < Heladeria.Toppings.length; l++) {
                                    System.out.println("(" + (l+1) + ") " + Heladeria.Toppings[l]);
                                }

                                System.out.println("Sabor de topping que desea elegir?");

                                opcion4 = Integer.valueOf(this.data.nextLine());
                                
                                if (j > 0) {
                                    Helado infoHeladoTemp = new Helado(Heladeria.Toppings[(opcion4-1)],ClienteAux.dato.cedula,1);
                                    infoHelados.agregar(infoHeladoTemp);
                                    ClienteAux.dato.saldo-=1;
                                }else{
                                    Helado infoHeladoTemp = new Helado(Heladeria.Toppings[(opcion4-1)],ClienteAux.dato.cedula,0);
                                    infoHelados.agregar(infoHeladoTemp);
                                }
                            } while (opcion4>(Heladeria.Toppings.length+2));
                            
                        }
                        
                        n++;
                    }else{
                        break;
                    }
                }
                
            } while ("n".equals(opcion));
            
            this.Clientes.extraerPrimerEnCola();
        }
        
        System.out.println("Recuento de Ventas:");
    }

    void Cliente(String datosCliente, String datosCliente0, String datosCliente1, String datosCliente2, String datosCliente3, Integer valueOf) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
    public class Cliente {
        String nombre;
        String apellido;
        String cedula;
        double saldo;
        
        Cliente(String Nombre, String Apellido, String Cedula,double Saldo){
            
            this.nombre=Nombre;
            this.apellido=Apellido;
            this.cedula=Cedula;
            this.saldo=Saldo;
        }
        
        public void restarSaldo(double monto){
            this.saldo=this.saldo-monto; 
        }
        
        public void imprimirDatos(){
            System.out.println("Esto son los datos: "+this.nombre+" "+this.apellido+" "+this.cedula+" ");
        }
    }
}



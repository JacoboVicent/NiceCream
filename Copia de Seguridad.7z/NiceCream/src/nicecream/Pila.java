
package nicecream;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;


/**
 *
 * @author USUARIO
 */
public class Pila {
  Nodo Cola; 
    PrintWriter pf;
    FileReader fr;
    int guardarPrecio;
    
    boolean pilaVacia(){
        return Cola == null;
        
    }
    
    void agregarSabor (String sabor){
        Cola = new Nodo (sabor, Cola);
        
    }
    
    void MostrarHelado() throws IOException {
        Cola cola = new Cola();
        NiceCream c = new NiceCream();
        if (!pilaVacia()) {
            System.err.println("No se encontraron helados registrados");
        
        } else if ("Cono".equals(Cola.SabordeHelado)){
             System.out.println("No se ha ingresado ningun sabor");
             System.err.println("La compra no ha sido realizada");
         
        } else{ 
            pf = new PrintWriter (new FileWriter("Ventas.txt", true));
            Nodo L = null;
            Nodo aux = L; 
            pf.append("Pedido de ");
            while (aux != null) {
                System.out.println(aux.SabordeHelado);
                pf.append(" " + aux.SabordeHelado);
                aux = aux.sig;
            }
        pf.append("Y su precio fue de: " + guardarPrecio + "$.");
        pf.append(" ");  
        pf.close();
        System.out.println("La compra fue realizada con exito.");
        guardarPrecio = 0;
        }
    }
    Nodo quitarBola() {
       if (!pilaVacia()){
           Nodo aux = new Nodo (Cola.SabordeHelado);
           if (Cola == null){
               Cola = null;
        } else {
               Cola = Cola.sig;
        }
        return aux;
       } else {
           System.out.println("La pila esta vacia");
           return null;
       } 
    }       
    void vaciarPila(){
        while (!pilaVacia()){
            quitarBola();
        }
    }

    void agregar(Helado infoHeladoTemp) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
